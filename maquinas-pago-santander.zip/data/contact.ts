export const whatsappLink = "https://wa.me/569XXXXXXXX?text=Hola,%20vengo%20de%20tu%20página%20web%20y%20me%20gustaría%20recibir%20más%20información%20sobre%20las%20máquinas%20de%20pago."

export const contactInfo = {
  phone: "+56 9 XXXX XXXX",
  email: "contacto@tudominio.cl"
}
