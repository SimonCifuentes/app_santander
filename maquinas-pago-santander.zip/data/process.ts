export const processSteps = [
  {
    number: 1,
    title: "Te Asesoro",
    description: "Contáctame y conversamos sobre tu negocio para elegir la máquina ideal para ti."
  },
  {
    number: 2,
    title: "Te la Entrego",
    description: "Recibe tu máquina completamente configurada y lista para usar. Sin complicaciones técnicas."
  },
  {
    number: 3,
    title: "¡A Vender!",
    description: "Listo! Ya puedes aceptar pagos con tarjeta y ver crecer tus ventas desde el primer día."
  }
]
